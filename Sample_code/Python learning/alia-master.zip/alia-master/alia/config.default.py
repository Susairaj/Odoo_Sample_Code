# Default Config file
debug = True
port = 8080
db_url = "sqlite:///app.db"
