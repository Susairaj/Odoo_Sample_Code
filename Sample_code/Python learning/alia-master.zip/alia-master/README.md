ALIA
====

An online learning environment to remotely teach unix and similar technologies. Currently uses docker, websockets and few other technologies.
