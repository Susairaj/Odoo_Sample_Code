c = get_config()
c.Exporter.template_file = 'reveal.tpl'
