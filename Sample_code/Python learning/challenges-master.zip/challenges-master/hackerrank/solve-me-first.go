package main
import "fmt"

func main() {
    var i int
    var j int
    fmt.Scanf("%d", &i)
    fmt.Scanf("%d", &j)
    fmt.Println(i+j

}
