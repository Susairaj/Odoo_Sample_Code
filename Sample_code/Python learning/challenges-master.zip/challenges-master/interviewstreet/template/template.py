import itertools
import sys
import logging


def main():
    data = sys.stdin.read().splitlines()        

    
if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    main()