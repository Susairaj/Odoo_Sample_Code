#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
gendo.utils
------------------

Helper functions used throughout Gendo.
"""
