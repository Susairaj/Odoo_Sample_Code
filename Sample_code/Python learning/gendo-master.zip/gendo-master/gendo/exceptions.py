#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
gendo.exceptions
----------------

All exceptions used in the Gendo code base are defined here.
"""
