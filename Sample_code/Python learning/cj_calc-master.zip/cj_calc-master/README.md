cj_calc
=======

This is a test facebook application designed in Flask and Bootstrap