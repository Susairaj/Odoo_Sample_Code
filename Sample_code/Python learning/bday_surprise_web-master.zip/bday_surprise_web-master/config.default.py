BASE_URL = 'https://graph.facebook.com/'
REQUEST_TOKEN_URL = None
ACCESS_TOKEN_URL = '/oauth/access_token'
AUTHORIZE_URL = 'https://www.facebook.com/dialog/oauth'
CONSUMER_KEY = '' # Facebook Application ID
CONSUMER_SECRET = '' # Facebook Application Secret
