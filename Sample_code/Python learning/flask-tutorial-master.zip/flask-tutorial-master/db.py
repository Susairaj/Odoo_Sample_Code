from flask.ext.sqlalchemy import SQLAlchemy

# Create the SQLAlchemy object, provided by Flask-SQLALchemy.
db = SQLAlchemy()