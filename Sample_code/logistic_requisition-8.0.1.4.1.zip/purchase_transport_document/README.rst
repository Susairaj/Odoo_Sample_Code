Purchase Transport Document
===========================
This module adds a new object "Transport Document" and allows to select
Documents in Purchase Orders. Other modules can depend on this simple one to
use the same documents.

This way it is possible to specify which documents have to be supplied with the
purchase. Possible examples (CMR, Bill of Lading and others) are provided as
demo data.
