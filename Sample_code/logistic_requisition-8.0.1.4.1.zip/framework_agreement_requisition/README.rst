Negociate framework agreement in the Tender
===========================================

This module allows you to negociate a framework agreement in the Tender.

To to so you have to check the box "Negociate Agreement".

The module add a state "Agreement selected" on the tender and on the Purchase
Order.

These will be the final state once you have chosen the agreement that best fits
your needs.

Once the selection is done just use the button "Agreement selected" on the
tender. That will close the flow of tender and the related PO accordingly.

Future Improvements
===================

The generated framework agreement does not contain the negociated prices.
Those need to be filled in manually.
