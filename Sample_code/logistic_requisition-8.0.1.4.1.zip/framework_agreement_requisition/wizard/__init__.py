from . import confirm_generate_agreement
