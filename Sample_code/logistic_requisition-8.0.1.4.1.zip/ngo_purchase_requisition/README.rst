NGO - Purchase Requisition
==========================

This is a glue module to define a specific view of Purchase Requisition
for NGO verticalization. The new view intent to give consistency with
Logistics Order and Logistics Requests views.


Contributors
------------

* Yannick Vaucher <yannick.vaucher@camptocamp.com>
