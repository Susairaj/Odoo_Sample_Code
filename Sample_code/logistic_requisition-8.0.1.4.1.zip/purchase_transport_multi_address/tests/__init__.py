# -*- coding: utf-8 -*-

from . import test_addresses
from . import test_consignee_purchase_order
