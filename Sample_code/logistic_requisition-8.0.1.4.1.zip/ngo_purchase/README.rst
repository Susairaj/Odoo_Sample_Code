NGO - Purchase
==============

This is a glue module to define a specific view of Purchase Order
for NGO verticalization. The new view is meant to give consistency with
Logistics Order and Logistics Requests views.

Note: ngo_purchase 1.2 needs framework_agreement 2.0. This is because the idea
of agreement portfolios was introduced there.

Contributors
------------

* Yannick Vaucher <yannick.vaucher@camptocamp.com>

