Purchase Origin Address
=======================

This module was merged into purchase_addresses
(https://github.com/OCA/stock-logistics-transport)
and will be dropped in v9.


Contributors
------------

* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Leonardo Pistone <leonardo.pistone@camptocamp.com>
* Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
