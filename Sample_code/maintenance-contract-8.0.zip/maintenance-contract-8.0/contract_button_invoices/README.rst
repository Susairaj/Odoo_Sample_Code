.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
    :alt: License

Contract Discount
=================

This module was written to extend the functionality of contracts to support set discount on contract invoice lintes.

Credits
=======

Contributors
------------

* Angel Moya <angel.moya@domatix.com>

Maintainer
----------

.. image:: http://domatix.com/wp-content/themes/yoo_nano3_wp/images/logo.png
   :alt: Domatix
   :target: http://domatix.com

This module is maintained by Domatix.

