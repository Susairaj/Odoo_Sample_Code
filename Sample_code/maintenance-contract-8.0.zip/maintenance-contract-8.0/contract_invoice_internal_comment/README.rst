.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
    :alt: License

Contract Invoice Internal Comment
=================================

This module was written to extend the functionality of contracts to allow set internal comment in contract, and set this comment on invoicing.


Credits
=======

Contributors
------------

* Angel Moya <angel.moya@domatix.com>

Maintainer
----------

.. image:: http://domatix.com/wp-content/themes/yoo_nano3_wp/images/logo.png
   :alt: Domatix
   :target: http://domatix.com

This module is maintained by Domatix.

