.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
    :alt: License

Contract Work Order Measures
============================

This module was written to extend the functionality of contracts to support:
* Measures in work orders

Credits
=======

Contributors
------------

* Angel Moya <angel.moya@domatix.com>

Maintainer
----------

.. image:: http://domatix.com/wp-content/themes/yoo_nano3_wp/images/logo.png
   :alt: Domatix
   :target: http://domatix.com

This module is maintained by Domatix.

