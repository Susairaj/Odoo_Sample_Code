# -*- coding: utf-8 -*-
{
    'name': 'Contract Discount',
    'version': '0.1',
    'author': 'Domatix',
    'summary': 'Contract Discount',
    'website': 'http://www.domatix.com',
    'images': [],
    'depends': ['account_analytic_analysis'],
    'category': 'Sales Management',
    'data': [
        'views/contract_view.xml',
    ],
    #'test': ['test/contract_discount.yml'],
    'installable': True,
    'application': False,
    'auto_install': False,
}
