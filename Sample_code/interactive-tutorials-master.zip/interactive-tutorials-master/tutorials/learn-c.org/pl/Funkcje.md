Tutorial
--------

Tutorial Code
-------------

#include <stdio.h>

int main(){
  return 0;
}

Expected Output
---------------
true

Solution
--------
