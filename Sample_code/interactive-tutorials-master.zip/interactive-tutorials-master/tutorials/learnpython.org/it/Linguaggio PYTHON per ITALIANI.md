# Linguaggio PYTHON per ITALIANI

La motivazione che mi spinge a scrivere queste pagine è la scarsezza di documentazione in Italiano ma sopratutto perché spesso
vengono tradotti anche i codici degli script che così tradotti purtroppo non funzionano. 


Sono **_AMICO_ ** colui il quale cercherà di aiutarti quando sei in difficoltà: <br>
Questa è, secondo me ,la trasposizione della parola ** Tutorial** <br>
Chi si trova  in difficoltà può scrivermi a questo indirizzo e-mail vonkes at gmail dot com  <br>

Come per quasi tutti i linguaggi di programmazione anche per Python usiamo il classico  **Ciao MONDO **

Diamo per scontato che abbiate installato sulla Vs. macchina ( PC/ o notebook) Python . Non ci dovrebbero essere difficoltà perché per i più noti sistemi operativi (Linux,Windows e Mac) ne esiste una versione. Io personalmente uso un notebook che ha i S.O. Windows e Linux  con installato Python ver. 2.6. 
Per vedere sul video il classico messaggio **"Hello WORD"** o **"Ciao MONDO"** dobbiamo prima lanciare l'interprete e quando  compare il segnale  del pronto[ ad eseguire i vostri comandi] **>>>**  scriviamo: 

**>>>** print "Ciao MONDO"  e subito dopo concludiamo premendo il tasto invio o return ( d'ora in avanti diamo per scontato che per concludere una riga si preme il tasto invio o return)

Il nostro amico Python ci risponderà facendo comparire sul video appunto la scritta **Ciao MONDO**

In questo tutorial Python ora **_AMICO_** vedrete due riquadri: in quello di sinistra è possibile inserire il codice che prepariamo per il nostro amico Python, mentre su quello di destra se clicchiamo sulla parola **Rum** o **Esegui** otteniamo la risposta alla nostra preparazione. Se invece clicchiamo sulla frase che segue **Rum**  e cioè **Mostra Output previsto** Python ci farà vedere ugualmente quello che avremmo voluto ma che non sarebbe stato possibile a seguito di qualche errore commesso nello scrivere il nostro codice nel riquadro di sinistra.

 L'obiettivo di questo esercizio è quello di ottenere la stampa del codice della finestra di input in quella di output Esattamente questo codice:

    "Ciao, Mondo!"

 
#Nel riquadro di sinistra scriviamo:
    # Questo codice deve stampare "Ciao, Mondo!"
        print "Ciao, Mondo!"

#Nel riquadro di destra dopo aver cliccato su Run

    Ciao, Mondo!

Mi preme ricordare che le righe di codice precedute dal segno '#' o cancelletto per il nostro amico Python sono solo righe di commento che servono a noi umani per ricordare meglio che cosa stavamo facendo. Troveremo utilissimi questi commenti se rivedremo il nostro codice dopo diverso tempo e ricorderemo meglio le nostre intenzioni; se stiamo esaminando  il codice di altri programmatori per capire meglio che cosa volevano codificare.Spero che questa precisazione meriti l'attenzione che io metto sempre per le cose che faccio.