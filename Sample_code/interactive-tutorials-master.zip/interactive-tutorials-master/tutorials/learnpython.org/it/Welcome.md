# Italiano

BENVENUTI
in questo Tutorial interattivo  che io chiamo **_AMICO_** [scritto per gli italiani] e ospitato da LEARNPYTHON.ORG 
che non finiremo mai di ringraziare-

L'originale appunto scritto e ospitato da LEARNPYTHON.ORG  è diretto sia ad  esperti programmatori che ai principianti. 
Ma principalmente a tutti coloro che desiderano imparare il linguaggio Python. NOI CI UNIANO A QUESTO MESSAGGIO e come conoscitore di
Python e di alcune librerie grafiche mi sento di aggiungere appunto **wxPython**  che è una di queste. Comincerò a parlarne non da subito
ma solo verso la fine degli argomenti trattati nell'area avanzata. Per i curiosi dico solo di scrivermi [vonkes at gmail dot com]

Potete cominciare dove volete basta scegliere il capitolo e seguire le istruzioni. Nella versione Inglese il tutorial interattivo prevede
un riquadro a sinistra dove potete inserire il vs codice e allorquando avrete terminato potrete vedere il risultato dei vostri sforzi nel 
riquadro di destra non prima di aver cliccato sulla parola **_Run_**. <br>
Nella malaugurata ipotesi che abbiate commesso un errore il nostro amico Python non potrà mostrarvi alcun risultato, ma il tutorial,
nella sua infinita bontà, cercherà di accontentarvi ma dovrete cliccare in corrispondenza della frase che segue **_Run_** e precisamente
su **_Show Expected Output_**  che significa **Ecco cosa ti aspettavi**. 
BUON LAVORO:

Cliccate sul capitolo con il quale volete iniziare  e seguite le istruzioni.

_Per gli studenti che consultano le pagine wiki in italiano consiglio di usare per le loro prove e per gli esercizi il tutorial Inglese; non sempre
gli esercizi usano la sintassi di python e allora il nostro amico non capisce e quindi non opera. Mi riservo di aiutarvi allorquando pur con sintassi
non conforme python eseguirà ugualmente il codice propostogli.

**Elenco dei Capitoli:**
=========================

- [[Linguaggio PYTHON per ITALIANI]] 
- [[Variabili e tipi]]
- [[Operatori_Base]]
- [[Funzioni con Argomenti Multipli]]
- [[Liste]]
- [[Formattazione delle stringhe]]
