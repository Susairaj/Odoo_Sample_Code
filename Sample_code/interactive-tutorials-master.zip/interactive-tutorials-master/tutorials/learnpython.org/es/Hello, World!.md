Tutorial
--------

Bienvenido a su primer tutorial! Da click en el botón "Run" en la parte inferior para ejecutar el código, o click en "Show Expected Output" para ver el resultado esperado después de alguna modificación. El objetivo de este ejercicio es hacer que el código imprima en la ventana de salida el siguiente texto:

    "Hello, World!"

Una ves que hallas modificado el código para imprimir el texto correcto, ejecútalo y observa si hace lo correcto.

Tutorial Code
-------------

# Este codigo necesita imprimir "Hello, World!"
print "Goodbye, World!"


Expected Output
---------------

Hello, World!

Solution
--------