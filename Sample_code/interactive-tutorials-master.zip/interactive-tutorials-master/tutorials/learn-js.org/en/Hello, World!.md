Tutorial
--------

Welcome to the first tutorial. In this tutorial you will learn how to write your first line of code.

JavaScript is a very powerful language. It can be used both within any browser in the world. On top of that, it can be used to write server-side code using node.js.

When using JavaScript inside the browser, we can change how the page looks like and how it behaves. In this tutorial, we will only focus on learning the language itself, and therefore we will only use one function to print out our results called "console.log".

Exercise
--------

You must print out to the console the sentence "Hello, World!".

Tutorial Code
-------------

console.log("Goodbye, World!");

Expected Output
---------------

Hello, World!

Solution
--------

console.log("Hello, World");
