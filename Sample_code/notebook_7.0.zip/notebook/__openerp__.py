{
	"name" : "Notebook",
	"version" : "0.1",
	"author" : "Stephen Raj",
	"website" : "http://www.boscoits.com/",
	"category" : "Generic Modules/Others",
	"depends" : ["base"],
	"description" : "Simple demo module",
	"init_xml" : ["notebook_view.xml"],
	"demo_xml" : [],
	"update_xml" : [],
	"active": False,
	"installable": True
}
