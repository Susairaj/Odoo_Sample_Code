===============================
Pos Order Line Product Image v9
===============================

This module adds product image in pos order line widget.

Installation
============

Just select it from available modules to install it, there is no need to extra installations.

Configuration
=============

Nothing to configure.

Credits
=======
Developer: Aswani pc @ cybrosys
Guidance: Nilmar Shereef @ cybrosys, shereef@cybrosys.in


